import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Assignment6
 * @author Donald Keita
 */
public class TownTest_STUDENT 
{
	Town town1, town2, town3, town4;
	String name1, name2, name3;
	Town townCopy;
	
	@BeforeEach
	public void setUp() throws Exception 
	{
		name1 = "Kansas City";
		name2 = "Miami";
		name3 = "Atlanta";
		town1 = new Town(name1);
		town2 = new Town(name1);
		town3 = new Town(name2);
		town4 = new Town(name3);
		townCopy = new Town(town1);
	}

	@AfterEach
	public void tearDown() throws Exception 
	{
		town1 = null;
		town2 = null;
		town3 = null;
		town4 = null;
		townCopy = null;
	}

	@Test
	public void testHashCode() 
	{
		assertEquals(town1.getName().hashCode(), town2.getName().hashCode());
		assertEquals(town1.getName().hashCode(), townCopy.getName().hashCode());
		assertEquals(town2.getName().hashCode(), townCopy.getName().hashCode());
		assertNotSame(town1.getName().hashCode(), town3.getName().hashCode());
		assertNotSame(town2.getName().hashCode(), town3.getName().hashCode());
	}

	@Test
	public void testCompareTo() 
	{
		assertTrue(town1.compareTo(town1) == 0);
		assertTrue(town1.compareTo(townCopy) == 0);
		assertTrue(town1.compareTo(town2) == 0);
		assertTrue(town2.compareTo(town1) == 0);
		assertTrue(town1.compareTo(town3) < 0);
	}

	@Test
	public void testEqualsObject() 
	{
		assertTrue(town1.equals(town1));
	    assertFalse(town2.equals(town3) || town3.equals(town2));
	    assertTrue(town1.equals(townCopy) && townCopy.equals(town1));
	    assertTrue(town2.equals(townCopy) && townCopy.equals(town2));

	}

	@Test
	public void testToString() 
	{
		assertEquals("Kansas City", town1.toString());
		assertEquals("Kansas City", town2.toString());
		assertEquals("Kansas City", townCopy.toString());
		assertEquals("Miami", town3.toString());
		assertEquals("Atlanta", town4.toString());	
	}
}
