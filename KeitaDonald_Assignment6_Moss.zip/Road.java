import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Assignment6
 * @author Donald Keita
 */
@SuppressWarnings("unused")
public class Road implements Comparable<Road> {

	private String name;
	private int weight;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Set<Town> Towns = new HashSet();
	
	private Town source;
	private Town destination;
	/**
	 * Constructor with weight preset at 1
	 * @param source - One town on the road
	 * @param destination - Another town on the road
	 * @param degrees - Weight of the edge, i.e., distance from one town to the other
	 * @param name - Name of the road
	 */
	public Road(Town source, Town destination, int degrees, String name) {
		this.name = name;
		this.weight = degrees;
		Towns.add(source);
		Towns.add(destination);
		this.source = source;
		this.destination =  destination;
	}
/**
 * getName method
 * @return name
 */
	public String getName() {
		return this.name;
	}
/**
 * getter and setter for getWeight method
 * @return
 */
	public int getWeight() {
		return weight;
	}
/**
 * setName method
 * @param name
 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * setName
	 * @param weight
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}

	/**
	 * 
	 * @return Towns - The location
	 */
	public Set<Town> getTowns() {
		return Towns;
	}

	/**
	 * setTowns
	 * @param towns
	 */
	public void setTowns(Set<Town> towns) {
		Towns = towns;
	}
/**
 * compareTo method
 */
	@Override
	public int compareTo(Road other) {
		//return this.getWeight() - other.getWeight();
		return this.name.compareTo(other.getName());
	}
/**
 * hashCode method
 */
	@Override
	public int hashCode() {
		
		final int num = 31;
		
		int res = 1;
		res = num * res + ((Towns == null) ? 0 : Towns.hashCode());
		
		res = num * res + ((name == null) ? 0 : name.hashCode());
		
		res = num * res + weight;
		
		return res;
	}
/**
 * equals method
 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		if (getClass() != obj.getClass())
			return false;
		
		Road other = (Road) obj;
		if (Towns == null) {
			if (other.Towns != null)
				return false;
		} else if (!Towns.equals(other.Towns))
			return false;
		
		return true;
	}
	
	
/**
 * toString method
 */
	@Override
	public String toString() {
		return source + ", " + destination + ", " + Integer.toString(this.weight) + ", " + this. name;
	}
	
	/**
	 * containsTown method
	 */

	
	public boolean contains(Town town) {
		if(this.source.equals(town) || this.destination.equals(town))
			return true;
		return false;
	}
	

}
