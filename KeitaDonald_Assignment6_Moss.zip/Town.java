import java.util.HashSet;
import java.util.Set;

/**
 * Assignment6
 * @author Donald Keita
 */
public class Town implements Comparable<Town> {
	private String name;
	private Set<Town> adjacentTowns;
	private int Weight;
	private Town Backpath;
	
	
	/**
	 * Constructor. Requires town's name. 
	 * @param name
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Town(String name) {
		this.name = name;
		adjacentTowns = new HashSet();
		Weight = Integer.MAX_VALUE;
		Backpath = null;
	}
	

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public Town(Town templateTown) {
		// TODO Auto-generated constructor stub
	    this.name = templateTown.name;
	    adjacentTowns = new HashSet();
	    Weight = Integer.MAX_VALUE;
	    Backpath = templateTown;
	}


    /**
	 * Returns the town's name 
	 * @return town's name
	 */
	public String getName() {
		return name;
	}
	
	
	/**
	 * @return the weight
	 */
	public int getWeight() {
		return Weight;
	}

	/**
	 * @param weight the weight to set
	 */
	public void setWeight(int weight) {
		this.Weight = weight;
	}
	
	/**
	 * @return the backpath
	 */
	public Town getBackpath() {
		return Backpath;
	}
	
	/**
	 * @param backpath the backpath to set
	 */
	public void setBackpath(Town backpath) {
		this.Backpath = backpath;
	}

	/**
	 * addTown method
	 * @param T
	 */
	public void addTowns(Town T) {
		adjacentTowns.add(T);
	}
	
	
	/**
	 * removeTown method
	 * @param T
	 */
	public void removeTowns(Town T) {
		adjacentTowns.remove(T);
	}
	
	/**
	 * getAdjacentTowns method
	 * @return AdjTowns
	 */
	public Set<Town> getAdjacentTowns() {
		return this.adjacentTowns;
	}

	/**
	 * setAdjacentTowns method
	 * @param adjacentTowns
	 */
	public void setAdjacentTowns(Set<Town> adjacentTowns) {
		this.adjacentTowns = adjacentTowns;
	}
	
	/**
	 * resetLocation method
	 */
	public void resetLocation() {
		Weight = Integer.MAX_VALUE;
		Backpath = null;
	}
	
	/**
	 * toString method
	 */
	@Override
	public String toString() {
		return this.name;
	}

	/**
	 * hashCode method
	 */
	@Override
	public int hashCode() {
		final int p = 31;
		int result = 1;
		result = p * result + ((this.name == null) ? 0 : this.name.hashCode());
		return result;
	}

	/**
	 * @return true if the town names are equal, false if not
	 */
	@Override 
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		if (getClass() != obj.getClass())
			return false;
		
		Town townObj = (Town) obj;
		
		if (this.name == null) {
			if (townObj.name != null)
				return false;
		} else if (!this.name.equals(townObj.name))
			return false;
		return compareTo((Town) obj) == 0;
	}
	

	/**
	 * Compare to method
	 * @return 0 if names are equal, a positive or negative number if the names are not equal
	 */
	@Override
	public int compareTo(Town o) {
		return this.name.compareTo(o.getName());
	}

	/**
	 * contains method
	 * @param townName
	 * @return true or false
	 */
    public boolean contains(String townName) {
		
		return (adjacentTowns.contains(townName));

	}

}
