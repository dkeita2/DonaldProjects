import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * Assignment6
 * @author Donald Keita
 */
public class TownGraphManager implements TownGraphManagerInterface {
	private TownGraph graph = new TownGraph();
	private ArrayList<String> roads = new ArrayList<String>();
	private ArrayList<String> towns= new ArrayList<String>();
	
	/**
	 * Populate the Town Graph by reading from a file
	 * @param file file read from
	 * @return true if read from file was successful, else return false
	 * @throws IOException if unable to read from the file
	 */
	@Override
	public boolean populateTownGraph(File file) throws IOException {
		Scanner input = new Scanner(file);
		boolean generate = false;
		while(input.hasNextLine()) {
			String str = input.nextLine();
			String inLine[] = str.split(";");
			String inEdge[] = inLine[0].split(","); 		
			addTown(inLine[1]);
			addTown(inLine[2]);
			addRoad(inLine[1], inLine[2], Integer.parseInt(inEdge[1]), inEdge[0]);
			generate = true;
		}
      return generate;
	}

	/**
	 * getTownFromMap method
	 * @param name 
	 * @return t or null
	 */
	public Town getTownFromMap(String name) {
		Set <Town> town = graph.vertexSet();
		for(Town t : town) {
			if(t.getName().equals(name))
				return t;
		}
		return null;
	}
	/**
	 * getRoadFromMapWeight method
	 * @param name
	 * @param a
	 * @param b
	 * @return max value integer
	 */
	public int getRoadFromMapWeight(String name,Town t1, Town t2) {
		Set <Road> roads = graph.edgeSet();
		for(Road r : roads) {
			Set<Town> towns =new HashSet<Town>();
			towns.add(t1);
			towns.add(t2);
			if(r.getName().equals(name))
				if(r.getTowns().equals(towns))
				   return r.getWeight();
		}
		return Integer.MAX_VALUE;
	}
	
	/**
	 * Adds a road with 2 towns and a road name
	 * @param town1 name of town 1 (source, destination)
	 * @param town2 name of town 2 (source, destination)
	 * @param roadName name of road
	 * @return true if the road was added successfully
	 */
	@Override
	public boolean addRoad(String source, String destination, int weight, String name) {
		
		Town start =getTownFromMap(source);
		Town end = getTownFromMap(destination);

		if (graph.containsVertex(start) && graph.containsVertex(end)) {
			if (!graph.containsEdge(start, end) ) {
				graph.addEdge(start, end, weight, name);
				Road road = (Road) graph.addEdge(start, end, weight, name);
				roads.add(road.getName());
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Returns the name of the road that both towns are connected through
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return name of road if town 1 and town2 are in the same road, returns null if not
	 */
	@Override
	public String getRoad(String source, String destination) {

		Town start = getTownFromMap(source);
		Town end = getTownFromMap(destination);

		if (graph.containsEdge(start, end)) {
			Road roadName = (Road) graph.getEdge(start, end);
			return roadName.getName();
		}
		return null;
	}
	
	
	/**
	 * Adds a town to the graph
	 * @param v the town's name  (lastname, firstname)
	 * @return true if the town was successfully added, false if not
	 */
	@Override
	public boolean addTown(String name) {
		Town otherTown = new Town(name);

		if (!graph.containsVertex(otherTown)) {
			graph.addVertex(otherTown);
			towns.add(name);
			return true;
		}
		return false;
	}
	
	/**
	 * Determines if a town is already in the graph
	 * @param v the town's name  (lastname, firstname)
	 * @return true if the town is in the graph, false if not
	 */
	@Override
	public boolean containsTown(String townName) {
		Town town = getTownFromMap(townName);

		return (graph.containsVertex(town));

	}
	
	/**
	 * Determines if a road is in the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return true if the road is in the graph, false if not
	 */
	@Override
	public boolean containsRoadConnection(String source, String destination) {
		Town start = new Town(source);
		Town end = new Town(destination);

		return (graph.containsEdge(start, end));
	}
	
	/**
	 * Creates an arraylist of all road titles in sorted order by road name
	 * @return an arraylist of all road titles in sorted order by road name
	 */
	@Override
	public ArrayList<String> allRoads() {

		ArrayList<String> sortingRoutes = new ArrayList<String>();

		sortingRoutes = roads;

		Collections.sort(roads);

		return sortingRoutes;
	}
	
	/**
	 * Deletes a road from the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @param roadName the road name
	 * @return true if the road was successfully deleted, false if not
	 */
	@Override
	public boolean deleteRoadConnection(String source, String destination, String name) {
		
		Town start =getTownFromMap(source);
		Town end = getTownFromMap(destination);

		
		
		
		if (graph.containsEdge(start, end) == true) {
			graph.removeEdge(start, end, getRoadFromMapWeight(name, start, end), name);
			roads.remove(name);
			return true;
		}
		return false;
	}
	
	/**
	 * Deletes a town from the graph
	 * @param v name of town (lastname, firstname)
	 * @return true if the town was successfully deleted, false if not
	 */
	@Override
	public boolean deleteTown(String name) {
		
		
		
		Town t = getTownFromMap(name);

		if (graph.containsVertex(t)) {
			graph.removeVertex(t);
			towns.remove(name);
			return true;
		}
		return false;
	}
	
	/**
	 * Creates an arraylist of all towns in alphabetical order (last name, first name)
	 * @return an arraylist of all towns in alphabetical order (last name, first name)
	 */
	@Override
	public ArrayList<String> allTowns() {
		
		
		ArrayList<String> sortingTowns = new ArrayList<String>();
		sortingTowns = towns;
		Collections.sort(sortingTowns);
		return sortingTowns;
	}
	
	/**
	 * Returns the shortest path from town 1 to town 2
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return an Arraylist of roads connecting the two towns together, null if the
	 * towns have no path to connect them.
	 * They will be in the format: startTown "via" road "to" endTown weight "miles"
	 * The last string in the ArrayList will be the total miles of the path in the
	 * following format: Total miles: #totalMiles
	 * As an example: if finding path from Town_1 to Town_10, the ArrayList<String>
	 * would be in the following format(this is a hypothetical solution):
	 * Town_1 via Road_2 to Town_3 4 miles (first string in ArrayList)
	 * Town_3 via Road_5 to Town_8 2 miles (second string in ArrayList)
	 * Town_8 via Road_9 to Town_10 2 miles (third string in ArrayList)
	 * Total miles: 8 miles
	 */
	@Override
	public ArrayList<String> getPath(String source, String destination) {
		
		
		Town start = getTownFromMap(source);
		Town end = getTownFromMap(destination);
		if(graph.containsVertex(end) && graph.containsVertex(start))
			return graph.shortestPath(start, end);
		return null;
	}
	
	/**
	 * 
	 * @param string
	 * @return start - the source of the trajectory
	 */
	public Town getTown(String string) {
		// TODO Auto-generated method stub
		Town start = new Town(string);
		return start;
	}

}
