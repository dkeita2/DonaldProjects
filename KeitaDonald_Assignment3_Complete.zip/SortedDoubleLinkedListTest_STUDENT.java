import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;



public class SortedDoubleLinkedListTest_STUDENT {
	DoubleComparator comparatorD;
	SortedDoubleLinkedList<Double> sortedLinkedDouble;
	

	@Before
	public void setUp() throws Exception {
		
		//STUDENT - use the SortedDoubleLinkedList<Double> for your STUDENT tests
		comparatorD = new DoubleComparator();
		sortedLinkedDouble = new SortedDoubleLinkedList<Double>(comparatorD);
	}

	@After
	public void tearDown() throws Exception {
		comparatorD = null;
		sortedLinkedDouble = null;
	}

	@Test
	//test the add to end. Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testAddToEndSTUDENT() {
		try {
			sortedLinkedDouble.addToEnd(241.0);
			assertTrue("Did not throw an UnsupportedOperationException", false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw an UnsupportedOperationException", true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
	}

	@Test
	//test the add to front. Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testAddToFrontSTUDENT() {
		try {
			sortedLinkedDouble.addToFront(458.0);
			assertTrue("Did not throw an UnsupportedOperationException", false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw an UnsupportedOperationException", true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
	}


	@Test
	//test the iterator next. Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testIteratorSuccessfulDoubleNext_STUDENT() {
		sortedLinkedDouble.add(241.0);
		sortedLinkedDouble.add(458.0);
		sortedLinkedDouble.add(530.0);
		sortedLinkedDouble.add(714.0);
		ListIterator<Double> iterator = sortedLinkedDouble.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(241.0, iterator.next(), .001);
		assertEquals(458.0, iterator.next(), .001);
		assertEquals(530.0, iterator.next(), .001);
		assertEquals(true, iterator.hasNext());
	}
	
	@Test
	//test the iterator previous. Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testIteratorSuccessfulDoublePrevious_STUDENT() {
		sortedLinkedDouble.add(241.0);
		sortedLinkedDouble.add(458.0);
		sortedLinkedDouble.add(530.0);
		sortedLinkedDouble.add(714.0);
		ListIterator<Double> iterator = sortedLinkedDouble.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(241.0, iterator.next(), .001);
		assertEquals(458.0, iterator.next(), .001);
		assertEquals(530.0, iterator.next(), .001);
		assertEquals(714.0, iterator.next(), .001);
		assertEquals(true, iterator.hasPrevious());
		assertEquals(714.0, iterator.previous(), .001);
		assertEquals(530.0, iterator.previous(), .001);
		assertEquals(458.0, iterator.previous(), 001);
	}
	
	@Test
	//test the iterator next when at the last element in the list. 
	//Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testIteratorNoSuchElementException_STUDENT() {
		sortedLinkedDouble.add(241.0);
		sortedLinkedDouble.add(458.0);
		sortedLinkedDouble.add(530.0);
		sortedLinkedDouble.add(714.0);
		ListIterator<Double> iterator = sortedLinkedDouble.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(241.0, iterator.next(), .001);
		assertEquals(458.0, iterator.next(), .001);
		assertEquals(530.0, iterator.next(), .001);
		assertEquals(true, iterator.hasNext());
		assertEquals(714.0, iterator.next(), .001);
		try{
			//no more elements in list
			iterator.next();
			assertTrue("Did not throw a NoSuchElementException",false);
		}
		catch (NoSuchElementException e)
		{
			assertTrue("Successfully threw a NoSuchElementException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the NoSuchElementException", false);
		}
	}
	
	
	@Test
	//test the iterator remove which is an unsupported operation. 
	//Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testIteratorUnsupportedOperationExceptionString() {
		sortedLinkedDouble.add(241.0);
		sortedLinkedDouble.add(458.0);
		sortedLinkedDouble.add(530.0);
		sortedLinkedDouble.add(714.0);
		ListIterator<Double> iterator = sortedLinkedDouble.iterator();
		try{
			//remove is not supported for the iterator
			iterator.remove();
			assertTrue("Did not throw a UnsupportedOperationException",false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw a UnsupportedOperationException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
	}

	@Test
	//test the add method 
	//Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testAdd_STUDENT() {
		sortedLinkedDouble.add(425.0);
		sortedLinkedDouble.add(900.0);
		sortedLinkedDouble.add(387.0);
		assertEquals(387.0, sortedLinkedDouble.getFirst(), .001);
		assertEquals(900.0, sortedLinkedDouble.getLast(), .001);
		sortedLinkedDouble.add(603.0);
		sortedLinkedDouble.add(816.0);
		assertEquals(387.0, sortedLinkedDouble.getFirst(), .001);
		assertEquals(900.0, sortedLinkedDouble.getLast(), .001);
		//deletes Elephant from linked list
		assertEquals(900.0, sortedLinkedDouble.retrieveLastElement(), .001);
		assertEquals(816.0, sortedLinkedDouble.getLast(), .001);
	}
	
	
	@Test
	//test the remove element at beginning of the list
	//Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testRemoveFirst_STUDENT() {
		sortedLinkedDouble.add(241.0);
		sortedLinkedDouble.add(458.0);
		assertEquals(241.0, sortedLinkedDouble.getFirst(), .001);
		assertEquals(458.0, sortedLinkedDouble.getLast(), .001);
		sortedLinkedDouble.add(530.0);
		assertEquals(241.0, sortedLinkedDouble.getFirst(), .001);
		// remove the first
		sortedLinkedDouble.remove(530.0, comparatorD);
		assertEquals(241.0, sortedLinkedDouble.getFirst(), .001);
	}
	
	@Test
	//test the remove element at end of the list
	//Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testRemoveEnd_STUDENT() {
		sortedLinkedDouble.add(241.0);
		sortedLinkedDouble.add(458.0);
		assertEquals(241.0, sortedLinkedDouble.getFirst(), .001);
		assertEquals(458.0, sortedLinkedDouble.getLast(), .001);
		sortedLinkedDouble.add(714.0);
		assertEquals(714.0, sortedLinkedDouble.getLast(), .001);
		//remove from the end of the list
		sortedLinkedDouble.remove(714.0, comparatorD);
		assertEquals(458.0, sortedLinkedDouble.getLast(), .001);
	}
	
	@Test
	//test the remove element in middle of the list
	//Use the corresponding test in the JUnit test provided
	//for you as an example
	public void testRemoveMiddle_STUDENT() {
		sortedLinkedDouble.add(241.0);
		sortedLinkedDouble.add(458.0);
		assertEquals(241.0, sortedLinkedDouble.getFirst(), .001);
		assertEquals(458.0, sortedLinkedDouble.getLast(), .001);
		sortedLinkedDouble.add(530.0);
		assertEquals(241.0, sortedLinkedDouble.getFirst(), .001);
		assertEquals(530.0, sortedLinkedDouble.getLast(), .001);
		assertEquals(3,sortedLinkedDouble.getSize());
		//remove from middle of list
		sortedLinkedDouble.remove(241.0, comparatorD);
		assertEquals(458.0, sortedLinkedDouble.getFirst(), .001);
		assertEquals(530.0, sortedLinkedDouble.getLast(), .001);
		assertEquals(2,sortedLinkedDouble.getSize());
	}

	
	private class DoubleComparator implements Comparator<Double>
	{

		@Override
		public int compare(Double arg0, Double arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
}
