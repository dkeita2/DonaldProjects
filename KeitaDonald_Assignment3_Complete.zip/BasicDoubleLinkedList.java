
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import javafx.scene.Node;

/**
 * Assignment 3
 * Method BasicDoubleLinkedList
 * CMSC-204
 * @author DONALD KEITA
 * @param <T>
 */
public class BasicDoubleLinkedList<T> extends Object implements Iterable<T> {
	
	protected Node<T> first;
	protected Node<T> last;
	protected int size;
	
	/**
	 * Constructor with no-arguments
	 */
	public BasicDoubleLinkedList() {
		this.first = null;
		this.last = null;
		this.size = 0;
	}
	
	/**
	 * Class Node
	 * @param <T>
	 */
	protected class Node<T> {
		protected T data;
		protected Node<T> previous;
		protected Node<T> next;
		
		 public Node()
	        {
	            data = null;
	            next = null;
	        }

	        public Node(T data)
	        {
	            this.data = data;
	        }

	        public Node(T data, Node<T> node)
	        {
	            data = data;
	            next = node;
	        }
	}
	

	
    /**
     * Notice you must not traverse the list to compute the size. 
     * This method just returns the value of the instance variable you use to keep track of size. 
     * @return size
     */
    public int getSize() {
		// TODO Auto-generated method stub
		return size;
	}

    /**
     * Adds element to the end of the list. Do not use iterators to implement this method. 
     * @param newElement
     * @return last
     */
    public BasicDoubleLinkedList<T> addToEnd(T newElement) {
		// TODO Auto-generated method stub
		Node<T> newNode = new Node<T>(newElement);
		if(getSize() == 0) {
			first = newNode;
			last = newNode;
		}
		else if(getSize() > 0){
			last.next = newNode;
		    last = newNode;
		}
		size++;
		return this;
	}

    /**
     * Adds element to the front of the list. Do not use iterators to implement this method. 
     * @param newElement
     * @return
     */
	public BasicDoubleLinkedList<T> addToFront(T newElement) {
		// TODO Auto-generated method stub
		Node<T> newNode = new Node<T>(newElement);
		if(size == 0) {
			first = newNode;
			last = newNode;
		}
		else {
			newNode.next = first;
            first = newNode;
		}
			
		size++;
		return this;
	}
	
	/**
	 * Returns but does not remove the last element from the list. 
	 * If there are no elements the method returns null. Do not implement this method using iterators. 
	 * @return last 
	 */
	public T getLast() {
		// TODO Auto-generated method stub
		if(getSize() > 0)
			return last.data;
		else
			return null;
	}

	/**
	 * Returns but does not remove the first element from the list. 
	 * If there are no elements the method returns null. Do not implement this method using iterators. 
	 * @return first
	 */
	public T getFirst() {
		// TODO Auto-generated method stub
		// Check if node list is not empty
        if (size > 0) {
            // Return node data
            return first.data;
        } else {
            // Return null
            return null;
        }
	}

	/**
	 * This method must be implemented using an inner class that implements ListIterator and defines 
	 * the methods of hasNext(), next(), hasPrevious() and previous(). 
	 * Remember that we should be able to call the hasNext() method as many times as we want without 
	 * changing what is considered the next element. 
	 */
	public class DoubleLinkedListIterator implements ListIterator<T> {
		// TODO Auto-generated method stub
		private Node<T> ip;
	    private Node<T> ipPrev;
	    
	    public DoubleLinkedListIterator()
	    {
	    ip = first;
	    ipPrev = null;
	    }
	    
	    public T next()
	    {
	    if(ip != null) {
	    T returnData = (T) ip.data;
	    ipPrev = ip;
	    ip = ip.next;
	    if(ip != null) 
	    	ip.previous = ipPrev;
	    return returnData;
	    }
	    else
	        throw new NoSuchElementException();
	        }
	    
	    public boolean hasNext()
	    {
	    if(ip==null)
	    return false;
	    else
	    return true;
	    }
	    
	    public T previous()
	    {
	    if(ipPrev != null)
	    {
	    //T returnData = ip.data;
	        ip = ipPrev;
	        ipPrev= ip.previous;
	        T returnData = ip.data;
	        return returnData;
	    }
	    else
	        throw new NoSuchElementException();
	    }
	    
	    public boolean hasPrevious()
	    {
	    if(ipPrev==null)
	        return false;
	    else 
	    	return true;
	    }
		
		public void remove() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
		
		public void add(T args0) throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
		
		public int nextIndex() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
		
		public int previousIndex() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
			
			public void set(T args) throws UnsupportedOperationException {
				throw new UnsupportedOperationException();
		}
	}

	/**
	 * iterator method that throws UnsupportedOperationException and NoSuchElementException
	 * and return an object of type DoubleLinkedListIterator.
	 */
	public ListIterator<T> iterator() throws UnsupportedOperationException, NoSuchElementException
    {
        // Return new list iterator
		return new DoubleLinkedListIterator();
    }
	
	
	/**
	 * Returns an arraylist of the items in the list from head of list to tail of list
	 * @return an arraylist of the items in the list
	 */
	    public ArrayList<T> toArrayList()
	    {
	    	
	        ArrayList<T> newList = new ArrayList<T>();
	        BasicDoubleLinkedList<T>.Node<T> currentNode = first;

	        // Iterate through node list
	        while (currentNode != null) {
	            newList.add((T) currentNode.data);
	            currentNode = currentNode.next;
	        }
	        return newList;
	    }


	 /**
	   * Removes and returns the first element from the list. If there are no elements the method returns null. 
	   * @return data element or null
	   */
	    public T retrieveFirstElement()
	    {
	        // Check if node list is not empty
	        if (size > 0) {
	            // Deep copy first node
	            Node<T> currentNode = first;

	            // Update new first node
	            first = first.next;

	            // Decrement list size variable
	            size--;

	            // Return node data
	            return currentNode.data;
	        } else {
	            // Return null
	            return null;
	        }
	    }

	/**
	 * Removes and returns the last element from the list. If there are no elements the method returns null. 
	 * @return data element or null
	 */
	    public T retrieveLastElement()
	    {
	        if (size > 0) {
	            // Initialize node pointers
	            Node<T> currentNode = first;
	            Node<T> previousNode = null;

	            // Iterate through node list
	            while (currentNode != null) {
	                // Check if current node is last node
	                if (currentNode.equals(last)) {
	                    // Set new last node to previous node
	                    last = previousNode;
	                    break;
	                }

	                // Update node pointers
	                previousNode = currentNode;
	                currentNode = currentNode.next;
	            }

	            // Decrement list size
	            size--;

	            // Return node data
	            return currentNode.data;
	        } else {
	            // Return null
	            return null;
	        }
	    }
	

	/**
     * Removes the first instance of the targetData from the list. 
     * Notice that you must remove the elements by performing a single traversal over the list.
     * @param element - the data element to be removed
     * @param comparator the comparator to determine equality of data elements
     * @return data element or null
     */
    public BasicDoubleLinkedList<T> remove(T element, Comparator<T> comparator)
    {
        // Initialize node pointers
        Node<T> currentNode = first;
        Node<T> previousNode = null;

        // Iterate through node list
        while (currentNode != null) {
            // Check if current node data matches query
            if (comparator.compare(currentNode.data, element) == 0) {
                // Check if current node is first/last/middle node
                if (currentNode.equals(first)) {
                    // Replace current first node
                    first = first.next;
                } else if (currentNode.equals(last)) {
                    // Replace current last node
                    last = previousNode;
                } else {
                    // Replace current middle node
                    previousNode.next = currentNode.next;
                }
            }

            // Update node pointers
            previousNode = currentNode;
            currentNode = currentNode.next;
        }
        size--;
		return this;
    }
}
