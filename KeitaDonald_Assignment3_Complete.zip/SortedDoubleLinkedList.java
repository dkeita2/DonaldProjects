
import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Assignment 3
 * Method SortedDoubleLinkedList
 * CMSC-204
 * @author DONALD KEITA
 * @param <T>
 */
public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T>{

	private Comparator<T> comp;
	
	/**
	 * Constructor containing a parameter
	 * @param comparator2
	 */
	public SortedDoubleLinkedList(Comparator<T> comparator2) {
		// TODO Auto-generated constructor stub
		this.comp = comparator2;
	}
	
	/**
	 * Method addToEnd that throws UnsupportedOperationException
	 */
	public BasicDoubleLinkedList<T> addToEnd(T data) throws UnsupportedOperationException {
		throw new UnsupportedOperationException("addToEnd() is unsupported for a sorted list");
	}

	/**
	 * Method addToFront that throws UnsupportedOperationException
	 */
	public BasicDoubleLinkedList<T> addToFront(T data) throws UnsupportedOperationException {
		throw new UnsupportedOperationException("addToFront() is unsupported for a sorted list");
	}
	
	/**
	 * Inserts the specified element at the correct position in the sorted list. 
	 * Notice we can insert the same element several times. 
	 * Your implementation must traverse the list only once in order to perform the insertion. 
	 * Do not implement this method using iterators. 
	 * Notice that you don't need to call any of the super class methods in order to implement this method. 
	 * @param newElement
	 * @return a reference to the current object
	 */
	public SortedDoubleLinkedList<T> add(T newElement) {
		// TODO Auto-generated method stub
		Node<T> newNode = new Node<T>(newElement);
		Node<T> currentNode = null;
		
	    if(getSize() == 0) {
	    	//currentNode = first;
	    	first = newNode;
	    	last = newNode;
	    }
	    
	    if(getSize() > 0) {
	    	currentNode = first;
	    	Node<T> prevNode = null;
	    	while (currentNode != null) {
	    	int comparason = comp.compare(newNode.data, currentNode.data);
	    	
	    	if(comparason == 0) {
	    		newNode.next = currentNode.next;
	    		currentNode.next = newNode;
	    		break;
	    	}
	    	else if(comparason < 0) {
	    		newNode.next = currentNode;
	    		if(currentNode.equals(first))
	    			first = newNode;
	    		else
	    			prevNode.next = newNode;
	    		break;
	    	}
	    	else {
	    		
	    		if(currentNode.equals(last)) {
	    			last.next = newNode;
	    			last = newNode;
	    			break;
	    		}
	    		else {
	    			prevNode = currentNode;
	    			currentNode = currentNode.next;
	    		}
	    	}
	      }
	    }
	    size++;
		return this;
	}
	
	 /**
     * Creates and returns new list iterator
     * @return New iterator
     */
    public ListIterator<T> iterator()
    {
        return super.iterator();
    }
    
    /**
     * Implements the remove operation by calling the super class remove method. 
     * @param data, comparator
     * @return data element or null
     */
    public BasicDoubleLinkedList<T> remove(T data, Comparator<T> comparator) {
    	//super.remove(data, comparator);
    	return super.remove(data, comparator);
    }
}
