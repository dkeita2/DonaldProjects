import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class BasicDoubleLinkedListTest_STUDENT {
	BasicDoubleLinkedList<Double> linkedDouble;
	DoubleComparator comparatorD;

	@Before
	public void setUp() throws Exception {
		
		//STUDENT: Use the linkedDouble for the STUDENT tests
		linkedDouble = new BasicDoubleLinkedList<Double>();
		//add doubles to the linkedDouble list
		//Example: linkedDouble.addToEnd(15.0);
		linkedDouble.addToEnd(11.0);
		linkedDouble.addToEnd(1989.0);
		linkedDouble.addToEnd(1960.0);
		linkedDouble.addToEnd(8.0);
		linkedDouble.addToEnd(15.0);
		comparatorD = new DoubleComparator();
		
	}

	@After
	public void tearDown() throws Exception {
		linkedDouble = null;
		comparatorD = null;
	}

	@Test
	public void testGetSize() {
		assertEquals(5,linkedDouble.getSize());
	}
	
	@Test
	public void testAddToEndSTUDENT(){
		//test addToEnd for the linkedDouble
		assertEquals(15.0, linkedDouble.getLast(), .001);
		linkedDouble.addToEnd(84.0);
		assertEquals(84.0, linkedDouble.getLast(), .001);
	}

	@Test
	public void testAddToFrontSTUDENT(){
		//test addToFront for the linkedDouble
		assertEquals(11.0, linkedDouble.getFirst(), .001);
		linkedDouble.addToFront(545.0);
		assertEquals(545.0, linkedDouble.getFirst(), .001);
	}

	@Test
	public void testGetFirstSTUDENT(){
		//test getFirst for the linkedDouble
		assertEquals(11.0, linkedDouble.getFirst(), .001);
		linkedDouble.addToFront(23.0);
		assertEquals(23.0, linkedDouble.getFirst(), .001);
	}

	@Test
	public void testGetLastSTUDENT(){
		//test getLast for the linkedDouble
		assertEquals(15.0, linkedDouble.getLast(), .001);
		linkedDouble.addToEnd(844.0);
		assertEquals(844.0, linkedDouble.getLast(), .001);
	}
	
	@Test
	public void testToArraySTUDENT(){
		//test toArray for the linkedDouble
		ArrayList<Double> list;
		linkedDouble.addToFront(25.0);
		linkedDouble.addToEnd(900.0);
		list = linkedDouble.toArrayList();
		assertEquals(25.0, list.get(0), .001);
		assertEquals(11.0, list.get(1), .001);
		assertEquals(1989.0, list.get(2),.001);
		assertEquals(1960.0, list.get(3),.001);	}
	
	@Test
	public void testIteratorSuccessfulNextSTUDENT(){
		//test the iterator for the linkedDouble
		//be throughly, use the corresponding test method in the provided 
		//JUnit test an example
		linkedDouble.addToFront(25.0);
		linkedDouble.addToEnd(900.0);
		ListIterator<Double> iterator = linkedDouble.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(25.0, iterator.next(), .001);
		assertEquals(11.0, iterator.next(), .001);
		assertEquals(1989.0, iterator.next(), .001);
		assertEquals(true, iterator.hasNext());
		assertEquals(1960.0, iterator.next(), .001);
	}
	
	@Test
	public void testIteratorSuccessfulPreviousSTUDENT(){
		//test the iterator for the linkedDouble
		//be through all, use the corresponding test method in the provided 
		//JUnit test an example
		linkedDouble.addToFront(25.0);
		linkedDouble.addToEnd(900.0);
		ListIterator<Double> iterator = linkedDouble.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(25.0, iterator.next(), .001);
		assertEquals(11.0, iterator.next(), .001);
		assertEquals(1989.0, iterator.next(), .001);
		assertEquals(true, iterator.hasPrevious());
		assertEquals(1989.0, iterator.previous(), .001);
		assertEquals(11.0, iterator.previous(), .001);
	}
	
	
	@Test
	public void testIteratorNoSuchElementExceptionNextSTUDENT(){
		//test the iterator for the linkedDouble.  Exception raised
		//when next is called after last element.
		//be throughal, use the the corresponding test method in the provided 
		//JUnit test an example
		linkedDouble.addToFront(25.0);
		linkedDouble.addToEnd(900.0);
		ListIterator<Double> iterator = linkedDouble.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(25.0, iterator.next(), .001);
		assertEquals(11.0, iterator.next(), .001);
		assertEquals(1989.0, iterator.next(), .001);
		assertEquals(true, iterator.hasNext());
		assertEquals(1960.0, iterator.next(), .001);
		try{
			//no more elements in list
			iterator.next();
			assertTrue("Throw a NoSuchElementException",true);
		}
		catch (NoSuchElementException e)
		{
			assertTrue("Successfully threw a NoSuchElementException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the NoSuchElementException", false);
		}
	}
	
	@Test
	public void testIteratorNoSuchElementExceptionPreviousSTUDENT(){
		//test the iterator for the linkedDouble.  Exception raised
		//when prvious is called when before the first element.
		//be throughal, use the the corresponding test method in the provided 
		//JUnit test an example
		linkedDouble.addToFront(25.0);
		linkedDouble.addToEnd(900.0);
		ListIterator<Double> iterator = linkedDouble.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(25.0, iterator.next(), .001);
		assertEquals(11.0, iterator.next(), .001);
		assertEquals(1989.0, iterator.next(), .001);
		assertEquals(1960.0, iterator.next(), .001);
		assertEquals(true, iterator.hasNext());
		assertEquals(true, iterator.hasPrevious());
		assertEquals(1960.0, iterator.previous(), .001);
		assertEquals(1989.0, iterator.previous(), .001);
		assertEquals(11.0, iterator.previous(), .001);
		assertEquals(25.0, iterator.previous(), .001);
		try{
			//no more elements in list
			iterator.previous();
			assertTrue("Did not throw a NoSuchElementException",false);
		}
		catch (NoSuchElementException e)
		{
			assertTrue("Successfully threw a NoSuchElementException",true);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			assertTrue("Threw an exception other than the NoSuchElementException", false);
		}
		
	}

	@Test
	public void testIteratorUnsupportedOperationExceptionSTUDENT(){
		//test the remove method for the iterator for the linkedDouble
		//be throughly, use the the corresponding test method in the provided 
		//JUnit test an example
		linkedDouble.addToFront(25.0);
		linkedDouble.addToEnd(900.0);
		ListIterator<Double> iterator = linkedDouble.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(25.0, iterator.next(), .001);
		assertEquals(11.0, iterator.next(), .001);
		assertEquals(1989.0, iterator.next(), .001);
		assertEquals(true, iterator.hasNext());
		assertEquals(1960.0, iterator.next(), .001);
		
		try{
			//remove is not supported for the iterator
			iterator.remove();
			assertTrue("Did not throw a UnsupportedOperationException",false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw a UnsupportedOperationException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
		
	}
	
	@Test
	public void testRemoveSTUDENT(){
		//test the remove method for the linkedDouble
		//be throughly, remove from the front of the list, the
		//end of the list and the middle of the list, 
		//use the the corresponding test method in the provided 
		//JUnit test an example
		// remove the first
				assertEquals(11.0, linkedDouble.getFirst(), .001);
				assertEquals(15.0, linkedDouble.getLast(), .001);
				linkedDouble.addToFront(15.0);
				assertEquals(15.0, linkedDouble.getFirst(), .001);
				linkedDouble.remove(15.0, comparatorD);
				assertEquals(11.0, linkedDouble.getFirst(), .001);
				//remove from the end of the list
				linkedDouble.addToEnd(900.0);
				assertEquals(900.0, linkedDouble.getLast(), .001);
				linkedDouble.remove(900.0, comparatorD);
				assertEquals(8.0, linkedDouble.getLast(), .001);
				//remove from middle of list
				linkedDouble.addToFront(25.0);
				assertEquals(25.0, linkedDouble.getFirst(), .001);
				assertEquals(8.0, linkedDouble.getLast(), .001);
				linkedDouble.remove(1989.0, comparatorD);
				assertEquals(25.0, linkedDouble.getFirst(), .001);
				assertEquals(8.0, linkedDouble.getLast(), .001);
				
	}
	
	@Test
	public void testRetrieveFirstElementSTUDENT(){
		//test retrieveLastElement for linkedDouble
		assertEquals(11.0, linkedDouble.getFirst(), .001);
		linkedDouble.addToFront(25.0);
		assertEquals(25.0, linkedDouble.getFirst(), .001);
		assertEquals(25.0, linkedDouble.retrieveFirstElement(), .001);
		assertEquals(11.0,linkedDouble.getFirst(), .001);
		assertEquals(11.0, linkedDouble.retrieveFirstElement(), .001);
		assertEquals(1989.0,linkedDouble.getFirst(), .001);
		
	}
	
	@Test
	public void testRetrieveLastElementSTUDENT(){
		//test retrieveLastElement for linkedDouble
		assertEquals(15.0, linkedDouble.getLast(), .001);
		linkedDouble.addToEnd(1960.0);
		assertEquals(1960.0, linkedDouble.getLast(), .001);
		assertEquals(1960.0, linkedDouble.retrieveLastElement(), .001);
		assertEquals(15.0,linkedDouble.getLast(), .001);
	}

	
	private class DoubleComparator implements Comparator<Double>
	{

		@Override
		public int compare(Double arg0, Double arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
}
