
public class UnmatchedException extends Exception {
	
	public UnmatchedException () {
		
	}
	
    public UnmatchedException (String message) {
		super(message);
	}
	

}
