
public class LengthException extends Exception {
	
	public LengthException()
	{
		
	}
	
	public LengthException(String text) {
		
		super(text);
	}
}
