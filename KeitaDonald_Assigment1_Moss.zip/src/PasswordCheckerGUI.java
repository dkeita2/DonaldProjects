import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.geometry.Insets;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 * 
 * @author Donald Keita
 * Assignment 1
 *CMSC 204
 */

public class PasswordCheckerGUI extends Application {
	// Declaration variable to display the rules of setting a valid password
	Label rulesOfPasswordLabel;
	Label passwordLabel;
	// Declaration of variable to hold the "Re-Type Password " Label 
	Label retypePasswordLabel;
	
	// Declare variable to hold the "Password" entry textfield
	TextField passwordTF;
	//Declare variable to hold the "Re-Type Password" entry textfield
	TextField retypePasswordTF;
	
	//Declare variable to hold the "Check Password" button
	Button checkPasswordButton;
	//Declare variable to hold the "Check Password in File" button
	Button checkFilePassButton;
	//Declare variable to hold the "Exit" button
	Button exitButton;
	
	// Create an instance of the PasswordCheckerUtility class in order to validate the passwords
	PasswordCheckerUtility check = new PasswordCheckerUtility();

	@Override
	public void start(Stage stage) {
		
		//Create the label that will display the rules of creating a password
		rulesOfPasswordLabel = new Label("Use the following rules when creating your passwords:\n"
				+"1. Length must be greater than 6; a strong password will contain at least 10 characters\n" 
				+"2. Must contain at least one upper case alpha character\n"
				+"3. Must contain at least one lower case alpha character\n"
				+"4. Must contain at least one numeric character\n"
				+"5. May not have more than 2 of the same character in sequence");
		
		// Create the password and re-type password labels to let the user know where to enter their desired password
		passwordLabel = new Label("Password");
		retypePasswordLabel = new Label(" Re-Type\n Password");
		
		//Create the textfields to allow the user to enter their desired password
		passwordTF = new TextField();
		passwordTF.setPrefWidth(210);
		retypePasswordTF = new TextField();
		retypePasswordTF.setPrefWidth(210);
		
		
		// Create the buttons that will be used by the password application to perform its function
		checkPasswordButton = new Button ("Check Password");
		checkPasswordButton.setMnemonicParsing(true);
		checkPasswordButton.setTooltip(new Tooltip("Click here to check if the desired password is valid."));
		checkPasswordButton.setPadding(new Insets(5,18,5,18));
		
		checkFilePassButton = new Button ("Check Passwords in File");
		checkFilePassButton.setMnemonicParsing(true);
		checkFilePassButton.setTooltip(new Tooltip("Click here to select the file containing the passwords. "));
		checkFilePassButton.setPadding(new Insets(5,18,5,18));
		
		exitButton = new Button ("Exit");
		exitButton.setMnemonicParsing(true);
		exitButton.setTooltip(new Tooltip("Click here to exit"));
		exitButton.setPadding(new Insets(5,18,5,18));
		
		checkPasswordButton.setOnAction(new CheckPasswordButtonEventHandler());
		checkFilePassButton.setOnAction(new CheckFilePasswordsButtonEventHandler());
		exitButton.setOnAction(new ExitButtonEventHandler());
		
		// Create a horizontal box that will hold the "Password" label and textfield in one row
		HBox passwordInput = new HBox(10);
		passwordInput.setAlignment(Pos.CENTER);
		passwordInput.getChildren().addAll(passwordLabel, passwordTF);
		
		// Create a horizontal box that will hold the "Re-Type Password" label and textfield in one row
		HBox retypePassword = new HBox(10);
		retypePassword.setAlignment(Pos.CENTER);
		retypePassword.getChildren().addAll(retypePasswordLabel, retypePasswordTF);
		
		
		// Create a vertical box that will nest the passwordInput and retypePasswordInput panes on top
		VBox passwordInfoPane = new VBox(10);
		passwordInfoPane.setPadding(new Insets(20,0,40,0));
		passwordInfoPane.setAlignment(Pos.CENTER);
		passwordInfoPane.getChildren().addAll(passwordInput, retypePassword);
		
		// Create a horizontal box that will place all the buttons next to each other
		HBox buttonPane = new HBox(25);
		buttonPane.setAlignment(Pos.CENTER);
		buttonPane.getChildren().addAll(checkPasswordButton, checkFilePassButton, exitButton);
		
		VBox contentPane = new VBox(30);
		contentPane.setAlignment(Pos.CENTER);
		contentPane.setPadding(new Insets(15,50,10,50));
		contentPane.getChildren().addAll(rulesOfPasswordLabel,passwordInfoPane,buttonPane);
		
		
		// Create a BorderPane to place contentPane into the center of the GUI display
		// contentPane contains all the nested HBox's and VBox's that were created to properly organized
		BorderPane displayPane = new BorderPane();
		displayPane.setCenter(contentPane);
		
		Scene scene = new Scene(displayPane);
		stage.setTitle("Password Checker");
		stage.setScene(scene);
		stage.show();
	}
		
		class CheckPasswordButtonEventHandler implements EventHandler<ActionEvent>
		{

			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				String password = null;
				String retypedPassword = null;
				
				password = passwordTF.getText().trim();
				retypedPassword = retypePasswordTF.getText().trim();
				
				try
				{
					if(!password.equals(retypedPassword))
					{
						UnmatchedException exception = new UnmatchedException("The password do not match");
						throw exception;
					}
					
					check.isValidPassword(password);
					JOptionPane.showMessageDialog(null,"Password is valid", "Password Status", JOptionPane.INFORMATION_MESSAGE);
					JOptionPane.showMessageDialog(null, "Password is OK but weak", "Password Status", JOptionPane.INFORMATION_MESSAGE);
				
				}
				
				catch(UnmatchedException exception)
				{
					JOptionPane.showMessageDialog(null, "The password do not match.","Password Status", JOptionPane.INFORMATION_MESSAGE);
					exception.printStackTrace();
				}
				catch (LengthException e)
				{
					JOptionPane.showMessageDialog(null, "The password must be at least 6 characters long.", "Password Error", JOptionPane.INFORMATION_MESSAGE );
					e.printStackTrace();
				}
				catch (NoDigitException e)
				{
					JOptionPane.showMessageDialog(null, "The password must contain at least one digit", "Password Error", JOptionPane.INFORMATION_MESSAGE);
					e.printStackTrace();
				}
				catch (NoUpperAlphaException e)
				{
					JOptionPane.showMessageDialog(null, "The password must contain at least one uppercase alphabetic character", "Password Error", JOptionPane.INFORMATION_MESSAGE);
					e.printStackTrace();
				}
				catch (NoLowerAlphaException e)
				{
					JOptionPane.showMessageDialog(null, "The password must contain at least one lowercase alphabetic character", "Password Error", JOptionPane.INFORMATION_MESSAGE);
					e.printStackTrace();
				}
				catch (InvalidSequenceException e)
				{
					JOptionPane.showMessageDialog(null,"The password cannot contain more than two of the same character in sequence", "Password Error", JOptionPane.INFORMATION_MESSAGE);
					e.printStackTrace();
				}
				
			}
			
		}
		 class CheckFilePasswordsButtonEventHandler implements EventHandler<ActionEvent>
		   {
		       @Override
		       public void handle(ActionEvent event)
		       {
		          
		           File selectedFile = null;
		           Scanner inputFile;
		           ArrayList<String> passwordList = new ArrayList<>();   // Declares a String ArrayList to hold the contents of the file being read.
		           ArrayList<String> illegalList = new ArrayList<>();   // Declares a String ArrayList to hold all the invalid passwords from the file that was read in.

		          
		           // Will display a window box allowing the user to select a file from their computer to open, in order to read its list of passwords.
		           JFileChooser fileChooser = new JFileChooser();
		           int status = fileChooser.showOpenDialog(null);
		          
		           if (status == JFileChooser.APPROVE_OPTION)
		           {
		               selectedFile = fileChooser.getSelectedFile();
		           }
		          
		           try
		           {
		               inputFile = new Scanner(selectedFile);
		              
		               // Read each password, line by line from the .txt file into a String ArrayList
		               while (inputFile.hasNext())
		               {
		                   passwordList.add(inputFile.nextLine());
		               }
		               illegalList = check.validPasswords(passwordList);
		              
		               // A string that will display all the invalid passwords and their error status messages one by one in a new row.
		               String illegal = "";
		              
		               // Loop through the illegalList ArrayList and place each invalid password one by one in a new row in the string.
		               for(int i =0; i < illegalList.size(); i++)
		               {
		                   illegal += illegalList.get(i) + "\n";
		               }
		      
		               // Display a message to the user showing all the invalid passwords that were read from the file, along with their error status message.
		               JOptionPane.showMessageDialog(null, illegal, "Illegal passwords", JOptionPane.INFORMATION_MESSAGE);
		              
		           }
		           catch (FileNotFoundException e)
		           {
		               e.printStackTrace();  
		           }
		       }
		   }
		class ExitButtonEventHandler implements EventHandler<ActionEvent>
		{

			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				System.exit(0);
				
			}
}
		public static void main(String[] args)
		{
			launch(args);
		}
}
		

