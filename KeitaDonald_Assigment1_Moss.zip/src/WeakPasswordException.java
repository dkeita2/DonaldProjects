
public class WeakPasswordException extends Exception {

	public WeakPasswordException() {
		// TODO Auto-generated constructor stub
	}

	public WeakPasswordException(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}
}
