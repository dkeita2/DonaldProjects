
public class NoLowerAlphaException extends Exception {
	
	public NoLowerAlphaException() {
		
	}
	
    public NoLowerAlphaException(String text) {
		super(text);
	}

}
