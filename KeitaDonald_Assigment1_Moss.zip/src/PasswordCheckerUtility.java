import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author diez4
 *
 */
public class PasswordCheckerUtility {

	 private static ArrayList<String> illegalPasswords; // Will hold the list of passwords that are found to be invalid from 
	 //the list that is passed into the validPasswords method.
	private static String password;   // Will hold the string that is passed into the isValidPassword method.

	/**
	 * 
	 */
	public PasswordCheckerUtility() {
		
	}
   /**
	public static boolean isWeakPassword(String strings) {
		// TODO Auto-generated method stub
		passwords = new ArrayList<String>();
		return false;
	}
 * @throws NoDigitException 
 * @throws LengthException 
 * @throws NoUpperAlphaException 
 * @throws NoLowerAlphaException 
 * @throws InvalidSequenceException 
	*/

	public static boolean isValidPassword(String passwordString) throws NoDigitException, LengthException, NoUpperAlphaException, NoLowerAlphaException, InvalidSequenceException 
	{
		password = passwordString;
		char firstChar = password.charAt(0);
		//int firstChar = 0;
    //the program checks if the password is less than 6 characters.
		if (password.length() < 6)
		{
			throw new LengthException ("The password must be at least 6 characters long.");  
		}
		
		// The program checks if the password contains a digit
				 if(!Character.isDigit(firstChar))
			       {
			           // Set the initial value of hasDigit to be false
			           boolean hasDigit = false;
			          
			           // Loop through the length of the password, and if there is a character that has a digit, then the variable hasDigit will be true.
			           for (int i = 0; i < password.length(); i++)
			           {  
			               firstChar = password.charAt(i);
			              
			               if(Character.isDigit(firstChar))
			               {
			                   hasDigit = true;
			               }
			           }
			          
			           // If there is no digit, then throw the NoDigitException
			           if(!hasDigit)
			           {
			               throw new NoDigitException ("The password must contain at least one digit.");  
			           }      
			       }
		
		//This program checks if the password contain a least an upper case letter
		
	       if(!Character.isUpperCase(password.charAt(firstChar)))
	       {
	           boolean hasUppercase = !password.equals(password.toLowerCase());
	          
	           //If the password does not have uppercase, then throw the NoUpperAlphaException.
	           if(!hasUppercase)
	           {
	           throw new NoUpperAlphaException ("The password must contain at least one uppercase alphabetic character.");
	           }
	       }
		
		//This program checks if the password contains at least a lower case letter
		if(!Character.isLowerCase(firstChar))
	       {
	           boolean hasLowercase = !password.equals(password.toUpperCase());
	          
	           if(!hasLowercase)
	           {
	           throw new NoLowerAlphaException ("The password must contain at least one lowercase alphabetic character.");
	           }
	       }
	

	//This program checks if the password contains more than two of the same character in sequence
       if(Character.isLowerCase(firstChar) && Character.isUpperCase(firstChar) && Character.isDigit(firstChar) )
       {
           for (int i = 0; i < password.length() - 3; i++)
           {
               if( (password.charAt(i) == password.charAt(i + 1))   && (password.charAt(i) == password.charAt(i+2)) )
               {
                   throw new InvalidSequenceException ("The password cannot contain more than two of the same character in sequence.");  
               }              
           }      
       }
       return true;
   }
	
	
	public static boolean isWeakPassword(String stringWord) {
		password = stringWord;
		if (password.length() >= 6 && password.length() <=10) {
		
		try {	
		throw new WeakPasswordException("Password is OK but weak.");
		}
			catch (WeakPasswordException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	return true;
	}
 
    public static ArrayList<String> validPasswords(ArrayList<String> passwords) {
    	illegalPasswords = new ArrayList<String>();
    	String notification = null;
    	
    	
    	for(int i = 0; i<passwords.size(); i++)
    	{
    		try 
    		{
    		isValidPassword(passwords.get(i));
    	}
    		catch (LengthException e){
    			notification = passwords.get(i) + " The password must be at least 6 characters long.";
				illegalPasswords.add(notification);
    			}
    		catch (NoDigitException e){
    			notification = passwords.get(i) + " The password must contain at least one digit.";
				illegalPasswords.add(notification);
			}
    		catch(NoUpperAlphaException e) {
    			notification = passwords.get(i) + " The password must contain at least one uppercase alphabetic character.";
				illegalPasswords.add(notification);
    		}
    		catch (NoLowerAlphaException e) 
			{
				notification = passwords.get(i) + " The password must contain at least one lowercase alphabetic character.";
				illegalPasswords.add(notification);
    	}
    		catch (InvalidSequenceException e) 
			{
				notification = passwords.get(i) + " The password cannot contain more than two of the same character in sequence.";
				illegalPasswords.add(notification);
			}  	
    }
    	return illegalPasswords;
 }
}
   
