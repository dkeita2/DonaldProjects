/**
 * 
 */

/**
 * @author diez4
 *
 */
public class InvalidSequenceException extends Exception {

	/**
	 * 
	 */
	public InvalidSequenceException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public InvalidSequenceException(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}
}
	