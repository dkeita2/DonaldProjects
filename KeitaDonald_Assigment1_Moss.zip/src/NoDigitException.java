
public class NoDigitException extends Exception {

	public NoDigitException() {
		// TODO Auto-generated constructor stub
	}

	public NoDigitException(String numeric) {
		super(numeric);
		// TODO Auto-generated constructor stub
	}
}