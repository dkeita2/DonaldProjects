import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MorseCodeConverterSTUDENTTest {
	
	File inputFileSTUDENT;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testPrintTree()
	{
		//Note the extra space between j and b - that is because there is an empty string that
		//is the root, and in the LNR traversal, the root would come between the right most
		//child of the left tree (j) and the left most child of the right tree (b).
		String correctResult = "h s v i f u e l r a p w j  b d x n c k y t z g q m o";
		String s = MorseCodeConverter.printTree();
		s = s.trim(); // take off preceeding or succedding spaces
		assertEquals(correctResult, s);
	}
	
	@Test
	public void testConvertToEnglishString() {	
		String converter1STUDENT = MorseCodeConverter.convertToEnglish(".. / .-.. --- ...- . / - --- / - .-. .- ...- . .-.. ");
		assertEquals("i love to travel",converter1STUDENT);
		
		String test2STUDENT ="i miss my mother";		
		String converter2STUDENT = MorseCodeConverter.convertToEnglish(".. / -- .. ... ... / -- -.-- / -- --- - .... . .-. ");
		assertEquals("i miss my mother", converter2STUDENT);
	}

	@Test
	public void testConvertToEnglishFile() throws FileNotFoundException {
		String test1STUDENT="the world should be a peaceful place";		
		getFile("studentTest1.txt");
		String converter1STUDENT = MorseCodeConverter.convertToEnglish(inputFileSTUDENT);
		assertEquals(test1STUDENT,converter1STUDENT);
		
		String test2STUDENT ="i would like to be a software developer";		
		getFile("studentTest2.txt");
		String converter2STUDENT = MorseCodeConverter.convertToEnglish(inputFileSTUDENT);
		assertEquals(test2STUDENT,converter2STUDENT);

	}
	
	public void getFile(String input) throws FileNotFoundException {		
		JFileChooser chooser = new JFileChooser();
		int status;

		chooser.setDialogTitle("Select Input File - " + input);
		status = chooser.showOpenDialog(null);

		if(status == JFileChooser.APPROVE_OPTION)
		{
			try
			{
				inputFileSTUDENT = chooser.getSelectedFile();
				// readFile();
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				JOptionPane.showMessageDialog(null, "There is a problem with this file", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}


}
