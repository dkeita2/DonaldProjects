import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Assignment 5 - Morse Code
 * @author Donald Keita
 */
public class MorseCodeConverter {
	
	private String code;
	private static MorseCodeTree tree = new MorseCodeTree();
	
	/**
	 * Constructor - no-args constructor
	 */
	public MorseCodeConverter() {
		this.code = null;
	}
	
	/**
	 * Constructor -  parameterized constructor that take one one argument of type string
	 * @param code
	 */
	public MorseCodeConverter(String code) {
		this.code = code;
	}

	/**
	 * returns a string with all the data in the tree in LNR order with an space in between them.
	 * Uses the toArrayList method in MorseCodeTree It should return the data in this order: 
     * "h s v i f u e l r a p w j b d x n c k y t z g q m o" 
     * Note the extra space between j and b - that is because there is an empty string that is the root, 
     * and in the LNR traversal, the root would come between the right most child of the left tree (j) and 
     * the left most child of the right tree (b). 
     * This is used for testing purposes to make sure the MorseCodeTree has been built properly 
	 * @return the data in the tree in LNR order separated by a space.
	 */
	public static String printTree() {

	       ArrayList<String> treeData = new ArrayList<String>();
	      
	       treeData = tree.toArrayList();
	      
	       String print = "";
	      
	       for(int i = 0; i < treeData.size(); i ++)
	       {
	           print += treeData.get(i) + " ";  
	       }
	      
	       return print;
	}
	
	/**
	 * Converts Morse code into English. Each letter is delimited by a space (� �). 
	 * Each word is delimited by a �/�. 
     * Example: 
     * code = ".... . .-.. .-.. --- / .-- --- .-. .-.. -.." 
     * string returned = "Hello World"
	 * @param code - the morse code
	 * @return the English translation
	 */
	public static String convertToEnglish(String code) {
		   String output = "";
	       String[] word; 
	       String[] letter; 
	       word = code.split(" / ");

	       for(int i = 0; i < word.length; i++)
	       {  
	           letter = word[i].split(" ");
	          
	           for(int j = 0; j < letter.length; j++)
	           {
	               output += tree.fetch(letter[j]);  
	           }
	          
	           output += " ";
	       }
	           output = output.trim();
	           
	           return output;
	}
	

	/**
	 * Converts a file of Morse code into English Each letter is delimited by a space (� �). 
	 * Each word is delimited by a �/�. 
     * Example: 
     * a file that contains ".... . .-.. .-.. --- / .-- --- .-. .-.. -.." 
     * string returned = "Hello World" 
	 * @param codeFile - name of the file that contains morse code
	 * @return the English translation of the file
	 * @throws FileNotFoundException
	 */
    public static String convertToEnglish(File codeFile) throws FileNotFoundException {

        String output = "";
        ArrayList<String> line = new ArrayList<String>();
        String[] word; 
        String[] letter; 
       
        Scanner inputFile;
        inputFile = new Scanner(codeFile);
       
        while (inputFile.hasNext())
        {  
            line.add(inputFile.nextLine());
        }
           
        inputFile.close();
       
        for(int i = 0; i < line.size(); i++)
        {
            word = line.get(i).split(" / ");
           
            for(int j = 0; j < word.length; j++)
            {
                letter = word[j].split(" ");
               
                for(int k = 0; k < letter.length; k++)
                {
                    output += tree.fetch(letter[k]);  
                }
                output += " ";
            }
        }
        output = output.trim();
       
        return output;
    }
}
