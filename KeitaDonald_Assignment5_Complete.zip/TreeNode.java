/**
 * Assignment 5 - Morse Code
 * @author Donald Keita
 * @param <T>
 */
public class TreeNode<T> {
	
	private TreeNode leftChild;
	private TreeNode rightChild;
	private T dataNode;

	/**
	 * No-args constructor
	 */
	public TreeNode() {
		this.dataNode = null;
		this.leftChild = null;
		this.rightChild = null;
	
	}
	
	/**
	 * Create a new TreeNode with left and right child set to null and data set to the dataNode 
	 * @param dataNode - the data to be stored in the TreeNode
	 * 
	 */
	public TreeNode(T dataNode) {
		this.dataNode = dataNode;
		this.leftChild = null;
		this.rightChild = null;
	}
	
	/**
	 * used for making deep copies 
	 * @param node - node to make copy of
	 */
	public TreeNode(TreeNode<T> node) {
		this.leftChild = node.leftChild;
		this.rightChild = node.rightChild;
		this.dataNode = node.dataNode;
	}

	/**
	 * Return the data within this TreeNode
	 * @return the data within this TreeNode
	 */
	public T getData() {
		return this.dataNode;
	}
	
	/**
	 * Set the data of portion of this node
	 * @param newData
	 */
    public void setData(T newData) {
		this.dataNode = newData;
	}
    
    /**
     * Retrieves the left child of this node.
     * @return  A reference to this node's left child.
     */
    public TreeNode<T> getLeftChild()
    {
        return this.leftChild;
    } 
    
    
    /**
     * Sets this node�s left child to a given node.
     * @param newLeftChild  A node that will be the left child. 
     */
    public void setLeftChild(TreeNode<T> newLeftChild)
    {
        this.leftChild = newLeftChild;
    }

	/**
	 * Retrieves the right child of this node.
	 * @return the rightChild
	 */
	public TreeNode<T> getRightChild() {
		return this.rightChild;
	}

	/**
	 * Sets this node�s right child to a given node.
	 * @param rightChild the rightChild to set
	 */
	public void setRightChild(TreeNode<T> rightChild) {
		this.rightChild = rightChild;
	}
      
}
