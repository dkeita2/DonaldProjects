import java.util.ArrayList;

/**
 * Assignment 5 - Morse Code
 * @author Donald Keita
 * @param <String>
 */
public class MorseCodeTree implements LinkedConverterTreeInterface<String> {

	private TreeNode<String> root;
	private String letter;
	
	public MorseCodeTree() {
		buildTree();
	}
	
	/**
	 * Returns a reference to the root
	 * @return reference to root
	 */
	@Override
	public TreeNode<String> getRoot() {
		// TODO Auto-generated method stub
		return this.root;
	}

	/**
	 * sets the root of the Tree
	 * @param newNode a TreeNode<T> that will be the new root
	 */
	@Override
	public void setRoot(TreeNode newNode) {
		// TODO Auto-generated method stub
		 TreeNode temporary = new TreeNode<>(newNode);
	        this.root = (TreeNode<String>) temporary;
	}

	
	/**
	 * Adds result to the correct position in the tree based on the code
	 * This method will call the recursive method addNode
	 * 
	 * @param code the code for the new node to be added
	 * @return the linkedConverterTree with the new node added
	 */
	@Override
	public LinkedConverterTreeInterface<String> insert(String code, String letter) {
		// TODO Auto-generated method stub
		addNode( root,code,letter );
		return this;
	}

	
	/**
	 * This is a recursive method that adds element to the correct position 
	 * in the tree based on the code.
	 * 
	 * @param root the root of the tree for this particular recursive instance of addNode
	 * @param code the code for this particular recursive instance of addNode
	 * @param letter the data of the new TreeNode to be added
	 */
	@Override
	public void addNode(TreeNode<String> root, String code, String letter) {
		// TODO Auto-generated method stub

		TreeNode<String> newRoot = (TreeNode<String>) root;
	    TreeNode<String> currentNode = (TreeNode<String>) root;
	    String newCode = null;
	    if(code.toString().length()==1)
	    {
	        if(code.toString().contains("."))
	        {
	            currentNode = new TreeNode<String>((String) letter);
	            newRoot.setLeftChild(currentNode);
	        }
	        if(code.toString().contains("-"))
	        {
	            currentNode = new TreeNode<String>((String) letter);
	            newRoot.setRightChild(currentNode);
	        }

	        return;
	    }
	    
		if(code.toString().charAt(0)=='.')
		{
		    newRoot = currentNode.getLeftChild();
		}
		if(code.toString().charAt(0)=='-')
		{
		    newRoot = currentNode.getRightChild();
		}
		newCode = code.toString().substring(1);
	    addNode((TreeNode<String>)newRoot, (String)newCode, letter);
		
		
	}

	
	/**
	 * Fetch the data in the tree based on the code
	 * This method will call the recursive method fetchNode
	 * 
	 * @param code the code that describes the traversals within the tree
	 * @return the result that corresponds to the code
	 */
	@Override
	public String fetch(String code) {
		// TODO Auto-generated method stub
		return fetchNode(root, code);
	}

	
	/**
	 * This is the recursive method that fetches the data of the TreeNode
	 * that corresponds with the code
	 * 
	 * @param root the root of the tree for this particular recursive instance of addNode
	 * @param code the code for this particular recursive instance of fetchNode
	 * @return the data corresponding to the code
	 */
	@Override
	public String fetchNode(TreeNode<String> root, String code) {
		// TODO Auto-generated method stub
	if(code.length()==1) {
			
			if (code.equals(".")) {
				letter = (String) root.getLeftChild().getData();
			}
			else {
				letter = (String) root.getRightChild().getData();
			}
			
		}
		else 
			{
				if(code.substring(0,1).equals("."))
				{
				 fetchNode(root.getLeftChild(),code.substring(1));
				}
				else
				{
				 fetchNode(root.getRightChild(),code.substring(1));
				}
			}
	
		return letter;
	}

	
	/**
	 * This operation is not supported for a LinkedConverterTree
	 * @param data data of node to be deleted
	 * @return reference to the current tree
	 * @throws UnsupportedOperationException
	 */
	@Override
	public LinkedConverterTreeInterface<String> delete(String data) throws UnsupportedOperationException {
		// TODO Auto-generated method stub
		return null;
	}

	
	/**
	 * This operation is not supported for a LinkedConverterTree
	 * @return reference to the current tree
	 * @throws UnsupportedOperationException
	 */
	@Override
	public LinkedConverterTreeInterface<String> update() throws UnsupportedOperationException {
		// TODO Auto-generated method stub
		return null;
	}

	
	/**
	 * This method builds the LinkedConverterTree by inserting TreeNodes<T>
	 * into their proper locations
	 */
	@Override
	public void buildTree() {
		//build root node
        root = new TreeNode<>("");
        TreeNode<String> eNode = new TreeNode<String>("e");
        root.setLeftChild(eNode);
        TreeNode<String> tNode = new TreeNode<String>("t");
        root.setRightChild(tNode);
        TreeNode<String> iNode = new TreeNode<>("i");
        eNode.setLeftChild(iNode);
        TreeNode<String> aNode = new TreeNode<>("a");
        eNode.setRightChild(aNode);
        TreeNode<String> sNode = new TreeNode<>("s");
        iNode.setLeftChild(sNode);
        TreeNode<String> uNode = new TreeNode<>("u");
        iNode.setRightChild(uNode);
        TreeNode<String> hNode = new TreeNode<>("h");
        sNode.setLeftChild(hNode);
        TreeNode<String> vNode = new TreeNode<>("v");
        sNode.setRightChild(vNode);
        TreeNode<String> fNode = new TreeNode<>("f");
        uNode.setLeftChild(fNode);

        TreeNode<String> rNode = new TreeNode<>("r");
        aNode.setLeftChild(rNode);
        TreeNode<String> wNode = new TreeNode<>("w");
        aNode.setRightChild(wNode);
        TreeNode<String> lNode = new TreeNode<>("l");
        rNode.setLeftChild(lNode);
        TreeNode<String> pNode = new TreeNode<>("p");
        wNode.setLeftChild(pNode);
        TreeNode<String> jNode = new TreeNode<>("j");
        wNode.setRightChild(jNode);

        TreeNode<String> nNode = new TreeNode<>("n");
        tNode.setLeftChild(nNode);
        TreeNode<String> mNode = new TreeNode<>("m");
        tNode.setRightChild(mNode);
        TreeNode<String> dNode = new TreeNode<>("d");
        nNode.setLeftChild(dNode);
        TreeNode<String> kNode = new TreeNode<>("k");
        nNode.setRightChild(kNode);

        TreeNode<String> bNode = new TreeNode<>("b");
        dNode.setLeftChild(bNode);
        TreeNode<String> xNode = new TreeNode<>("x");
        dNode.setRightChild(xNode);
        TreeNode<String> cNode = new TreeNode<>("c");
        kNode.setLeftChild(cNode);
        TreeNode<String> yNode = new TreeNode<>("y");
        kNode.setRightChild(yNode);

        TreeNode<String> gNode = new TreeNode<>("g");
        mNode.setLeftChild(gNode);
        TreeNode<String> oNode = new TreeNode<>("o");
        mNode.setRightChild(oNode);
        TreeNode<String> zNode = new TreeNode<>("z");
        gNode.setLeftChild(zNode);
        TreeNode<String> qNode = new TreeNode<>("q");
        gNode.setRightChild(qNode);			
		
	}

	
	/**
	 * Returns an ArrayList of the items in the linked converter Tree in LNR (Inorder) Traversal order
	 * Used for testing to make sure tree is built correctly
	 * @return an ArrayList of the items in the linked Tree
	 */
	@Override
	public ArrayList<String> toArrayList() {
		// TODO Auto-generated method stub
		ArrayList<String> printTree = new ArrayList<String>();
		LNRoutputTraversal(root, printTree);
	
	return printTree;
	}

	
	/**
	 * The recursive method to put the contents of the linked converter tree in an ArrayList<T> 
	 * LNR (Inorder)
	 * @param root the root of the tree for this particular recursive instance
	 * @param list the ArrayList that will hold the contents of the tree in LNR order
	 */
	@Override
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		// TODO Auto-generated method stub
		if (root!=null)
		{
			//recusive method to traverse through the binary tree in LNR (Inorder)
			LNRoutputTraversal(root.getLeftChild(),list);
			list.add(root.getData());
			LNRoutputTraversal(root.getRightChild(),list);
		}
	}
}
