
/**
 * Represents a Property object 
 * @author Donald Keita
 */
public class Property {

	private String owner;
	private String city;
	private double rentAmount;
	private String propertyName;
	private Plot plot;
	
	/**
	 * No-arg Constructor, creates a new object with default values of empty strings and 0 for rent amount
	 */
	public Property() {
		this.owner = "";
		this.city = "";
		this.rentAmount = 0;
		this.propertyName = "";
		this.plot = new Plot();
	}
	
	/**
	 * Copy Constructor, creates a new object using the information of the object passed to it.
	 * @param p - a Property object
	 */
	public Property(Property p) {
	
		this.propertyName = p.getPropertyName();
		this.city = p.getCity();
		this.rentAmount = p.getRentAmount();
		this.owner = p.getOwner();
	}
	
	/**
	 * Constructor, Parameterized constructor that takes 4 arguments
	 * @param propertyName - property name
	 * @param propertyLocation - city where the property is located
	 * @param rentAmount - rent amount
	 * @param propertyOwner - the owner's name
	 */
	
	public Property(String propertyName, String city, double rentAmount, String owner) {

		this.propertyName = propertyName;
		this.city = city;
		this.rentAmount = rentAmount;
		this.owner = owner;
	}
	
	/**
	 * Constructor, Parameterized constructor that takes 8 arguments
	 * @param propertyName
	 * @param city
	 * @param rentAmount
	 * @param owner
	 * @param x
	 * @param y
	 * @param width
	 * @param depth
	 */
	public Property(String propertyName, String city, double rentAmount, String owner, 
			int x, int y, int width, int depth) {

		this.propertyName = propertyName;
		this.city = city;
		this.rentAmount = rentAmount;
		this.owner = owner;
		this.plot = new Plot(x, y, width, depth);
	}

	/**
	 * This method returns the name of the property owner
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * This method set the name of the property owner
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * This method returns the city where the property is located
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * This method set the city where the property is located
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * This method returns the renting amount of the property 
	 * @return the rentAmount
	 */
	public double getRentAmount() {
		return rentAmount;
	}

	/**
	 * This method set the renting amount of the property
	 * @param rentAmount the rentAmount to set
	 */
	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}

	/**
	 * This method returns the name of the property
	 * @return the propertyName
	 */
	public String getPropertyName() {
		return propertyName;
	}

	/**
	 * This method set the name of the property
	 * @param propertyName the propertyName to set
	 */
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	/**
	 * This method returns return the plot of the property
	 * @return the plot
	 */
	public Plot getPlot() {
		return plot;
	}

	/**
	 * This method set the plot of the property
	 * @param plot the plot to set
	 */
	public void setPlot(Plot plot) {
		this.plot = plot;
	}

	/**
	 *Prints out the name, city, owner and rent amount for a property
	 *@return the string representation of a Property object in the following format: 
	 *                 Property Name: propertyName 
	 *                 Located in propertyLocation
	 *                 Belonging to: propertyOwner
	 *                 Rent Amount: rentAmount 
     *    Be sure the last item is the rent amount, preceded by a space.  
	 */
	@Override
	public String toString() {
		
		return "Property Name:" + this.propertyName + "\n\tLocated in " + this.city + "\n\tBelonging to: "
				+ this.owner + "\n\tRent Amount: " + this.rentAmount;
	}
    
}
