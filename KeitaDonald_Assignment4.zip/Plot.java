/**
 * Represents a Plot object
 * @author Donald Keita
 */
public class Plot {

	private int x;
	private int y;
	private int width;
	private int depth;
	/**
	 * No-args constructor
	 */
	public Plot() {
		this.x = 0;
		this.y = 0;
		this.width = 1;
		this.depth = 1;
	}
	
	/**
	 * Copy Constructor, creates a new object using the information of the object passed to it.
	 * @param plot
	 */
	public Plot(Plot plot) {
		this.x = plot.x;
		this.y = plot.y;
		this.width = plot.width;
		this.depth = plot.depth;
	}
	
	/**
	 * Parameterized Constructor that takes 4 arguments
	 * @param x
	 * @param y
	 * @param width
	 * @param depth
	 */
	public Plot(int x, int y, int width, int depth) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.depth = depth;
	}
	
	
	/**
	 * This method test if a property overlaps another property
	 * @param plot
	 * @return true or false
	 */
	public boolean overlaps(Plot plot) {
		return x < plot.x + plot.width && x + width > plot.x && y < plot.y + plot.depth && y + depth > plot.y;
	}
	
	/**
	 * This method determines if a property is in the company dimension
	 * @param plot
	 * @return true or false
	 */
	public boolean encompasses(Plot plot) {
		int xx = plot.x + plot.width;
		int yy = plot.y + plot.depth;
		
		return plot.x >= x && plot.y >= y && xx <= (x + width) && yy <= (y + depth);
	}
	
	/**
	 * This method returns the x value
	 * @return x
	 */
	public int getX() {
		return x;
	}
	/**
	 * This method set the x value
	 * @param x
	 */
	public void setX(int x) {
		this.x = x;
	}
	/**
	 * This method returns the y value
	 * @return the y
	 */
	public int getY() {
		return y;
	}
	
	/**
	 * This method set the y value
	 * @param y
	 */
	public void setY(int y) {
		this.y = y;
	}
	
	/**
	 * This method returns the width value
	 * @return the width
	 */
	public int getWidth() {
		return width;
	}
	
	/**
	 * This method set width value
	 * @param width the width to set
	 */
	public void setWidth(int width) {
		this.width = width;
	}
	
	/**
	 * This method returns the depth value
	 * @return the depth
	 */
	public int getDepth() {
		return depth;
	}
	
	/**
	 * This method set the depth value
	 * @param depth the depth to set
	 */
	public void setDepth(int depth) {
		this.depth = depth;
	}
	
	/**
	 * Prints out the name, city, owner and rent amount for a property 
	 * @return the string representation of a Plot object in the following format: 
               Upper left: (1,1); Width: 3 Depth: 3 
	 */
	@Override
	public String toString() {
		return "Plot [x=" + x + ", y=" + y + ", width=" + width + ", depth=" + depth + "]";
	}
	
	
	
}

