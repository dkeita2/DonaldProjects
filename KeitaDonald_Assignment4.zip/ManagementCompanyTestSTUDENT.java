



import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class ManagementCompanyTestSTUDENT {
	
	ManagementCompany mStudent;
	
	@Before
	public void setUp() throws Exception {
		//student create a management company
		mStudent= new ManagementCompany("Techno Solution", "2545",8);
		//student add three properties, with plots, to mgmt 64company 
		mStudent.addProperty("Country Ridge", "Germantown", 1550.50, "Don Jackson",1,2,1,2);
		mStudent.addProperty("Smooth Stone", "Montgomery Village", 1060.00, "Carine Lomb",3,2,3,1);
		mStudent.addProperty("Bel Pre", "Silver Spring", 3400.40, "Rick Steves",5,2,1,2);
		
		
	}

	@After
	public void tearDown() {
		//student set mgmt co to null  
		mStudent = null;
	}

	@Test
	public void testAddPropertyDefaultPlot() {
		//student should add property with 4 args & default plot
		assertEquals(mStudent.addProperty("Town Square", "Rockville", 3045.60, "Omar Keita"),2,0);
		//student should add property with 8 args
		assertEquals(mStudent.addProperty("Burnside", "Rockville", 2600.00, "Camouz Gafunk",2,3,2,3),3,0);
		//student should add property that exceeds the size of the mgmt co array and can not be added, add property should return -1
		assertEquals(mStudent.addProperty("Burnside", "Rockville", 2600.00, "Camouz Gafunk",2,3,2,3),-4,0);
	}
 
	@Test
	public void testMaxPropertyRent() {		
				
				String maxPropRentArray = mStudent.maxPropertyRent();  
				assertTrue(maxPropRentArray.contains("1550.5"));
	}

	@Test
	public void testTotalRent() {
		//student should test if totalRent returns the total rent of properties
		assertEquals(mStudent.totalRent(),2610.50,0);
	}

 }
