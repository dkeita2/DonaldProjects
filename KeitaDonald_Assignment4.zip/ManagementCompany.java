
/**
 * Represents management company object 
 * @author Donald Keita
 */
public class ManagementCompany {

	
	private final int MAX_PROPERTY = 5;
	private double managmntFee;
	private String name;
	private Property[] properties;
	private String taxId;
	private final int MAX_WIDTH = 10;
	private final int MAX_DEPTH = 10;
	//private int x;
	//private int y;
	//private int width;
	//private int depth;
	private Plot plot;
	private int numberOfprop;
	

	/**
	 * No-Arg Constructor that creates a ManagementCompany object using empty strings and a default Plot.
	 *  "properties" array is initialized here as well. 
	 */
	public ManagementCompany() {
		this.managmntFee = 0.0;
		this.name = "";
		this.taxId = "";
		//this.setPlot(new Plot());
		this.properties = new Property[MAX_PROPERTY];
		this.numberOfprop = 0;
		this.plot = new Plot(0,0, getMAX_WIDTH(), getMAX_DEPTH());
	}

	/**
	 * Constructor Creates a ManagementCompany object using the passed informations. 
	 * "properties" array is initialized here as well. 
	 * @param companyName - management company name
	 * @param taxId - tax id
	 * @param managmntFee - management fee
	 */
	
	public ManagementCompany(String name, String taxId, double mgmFee) {
		
		this.name = name;
		this.taxId = taxId;
		this.managmntFee = mgmFee;
		this.numberOfprop = 0;
		this.properties = new Property[MAX_PROPERTY];
		this.plot = new Plot(0, 0, 10, 10);
	}

	/**
	 * Copy Constructor creates a ManagementCompany object using another ManagementCompany object. 
	 * "properties" array is initialized here as well. 
	 * @param otherCompany
	 */
	public ManagementCompany(ManagementCompany otherCompany) {
		this.name = otherCompany.name;
		this.taxId = otherCompany.taxId;
		this.managmntFee = otherCompany.managmntFee;
		this.numberOfprop = 0;
		this.properties = new Property[MAX_PROPERTY];
		this.setPlot(new Plot());
		this.plot = otherCompany.getPlot();
	}
	
	/**
	 * Constructor Creates a ManagementCompany object using the passed informations. 
	 * "properties" array is initialized here as well.
	 * @param name
	 * @param taxId
	 * @param managmntFee
	 * @param x
	 * @param y
	 * @param width
	 * @param depth
	 */
	public ManagementCompany(String name, String taxId, double managmntFee, int x, int y, int width, int depth) {
		this.name = name;
		this.taxId = taxId;
		this.managmntFee = managmntFee;
		this.plot = new Plot(x, y, width, depth);
		this.numberOfprop = 0;
		this.properties = new Property[MAX_PROPERTY];
	}

	/**
	 * Adds the property object to the "properties" array. 
	 * @param property - a property object
	 * @return Returns either -1 if the array is full, -2 if property is null, 
	 * -3 if the plot is not contained by the MgmtCo plot, -4 of the plot overlaps any other property, 
	 * or the index in the array where the property was added successfully.   
	 */
	
	
	public int addProperty(Property p) {
   		
	 if(p == null)
	     return -2;
	 else if(!(numberOfprop < getMAX_PROPERTY()))
		 return -1;
	 else {
    	 properties[numberOfprop] = p;
    	 return numberOfprop ++;
     }
	}  

	
	/**
	 * Creates a property object and adds it to the "properties" array, in a default plot. 
	 * @param propertyName
	 * @param city
	 * @param rentAmount
	 * @param owner
	 * @return Returns either -1 if the array is full, -2 if property is null,
	 * -3 if the plot is not contained by the MgmtCo plot, -4 of the plot overlaps any other property, 
	 * or the index in the array where the property was added successfully.
	 */
	public int addProperty(String propertyName, String city, double rentAmount, String owner) {
		
		Plot plotProp  = new Plot(0,0,1,1);
        Property p;
		p = new Property(propertyName, city, rentAmount, owner);
		p.setPlot(plotProp);

		
		for(int i=0;i<MAX_PROPERTY && properties[i]!=null;i++) {
	    	 if(properties[i].getPlot().overlaps(plotProp))
	    		 return -4;	 
	     }
	     
		if(!(numberOfprop < getMAX_PROPERTY()))
			 return -1;
		else if(this.plot.encompasses(plotProp) == false)
	    	 return -3;
		else {
	    	 properties[numberOfprop] = p;
	    	 return numberOfprop ++;
	     }
	}
	
	/**
	 * Creates a property object and adds it to the "properties" array. 
	 * @param propertyName
	 * @param city
	 * @param rentAmount
	 * @param owner
	 * @param x
	 * @param y
	 * @param width
	 * @param depth
	 * @return Returns either -1 if the array is full, -2 if property is null, 
	 * -3 if the plot is not contained by the MgmtCo plot, -4 of the plot overlaps any other property, 
	 * or the index in the array where the property was added successfully.
	 */
	public int addProperty(String propertyName, String city, double rentAmount, 
			               String owner, int x, int y, int width, int depth) {
		Property p;
		p = new Property(propertyName, city, rentAmount, owner);
		Plot plotProp = new Plot(x, y, width, depth);
		p.setPlot(plotProp);

		for(int i=0;i<MAX_PROPERTY && properties[i]!=null;i++) {
	    	 if(properties[i].getPlot().overlaps(plotProp))
	    		 return -4;	 
	     }
		if(!(numberOfprop < getMAX_PROPERTY()))
			 return -1;
		else if(this.plot.encompasses(plotProp) == false)
	    	 return -3;
		else {
	    	 properties[numberOfprop] = p;
	    	 return numberOfprop ++;
	     }
	}
	    	
	
     
	/**
	 * Return the MAX_PROPERTY constant that represent the size of the "properties" array. 
	 * @return the MAX_PROPERTY a constant attribute for this class that is set 5
	 */
	public int getMAX_PROPERTY() {
		return MAX_PROPERTY;
	}
		
	/**
	 * Return MAX_DEPTH constant that represent the depth of the plot
	 * @return the mAX_WIDTH
	 */
	public int getMAX_WIDTH() {
		return MAX_WIDTH;
	}

	/**
	 * Return MAX_WIDTH constant that represent the width of the plot
	 * @return the mAX_DEPTH
	 */
	public int getMAX_DEPTH() {
		return MAX_DEPTH;
	}

	/**
	 * Displays the information of the property at index i 
	 * @param i
	 * @return information of the property at index i
	 */
	 private String displayPropertyAtIndex(int i) {
    	 String information = "";
    	 if (i < numberOfprop)
    		  information = properties[i].toString();
    	 return information;
    }
	
	/**
	 * This method is returning the index of the property with the maximum rent amount. 
     *NOTE: For simplicity assume that each "Property" object's rent amount is different.
	 * @return maxIndex, the index of the property with the maximum rent amount
	 */
	private int maxPropertyIndex() {
		int maxIndex = 0;
		double highest = properties[maxIndex].getRentAmount();
		for (int i = 0; i < MAX_PROPERTY; i++)
		{	
			if(properties[i]!=null && properties[i].getRentAmount() > highest) {
				highest = properties[i].getRentAmount();
				maxIndex = i;
			}
		}
		return maxIndex;
	}
	
    
	/**
	 * This method finds the property with the maximum rent amount. 
	 * NOTE: For simplicity assume that each "Property" object's rent amount is different. 
	 * @return double, the maximum rent amount
	 */
	public String maxPropertyRent() {
		double highestRent = properties[maxPropertyIndex()].getRentAmount();
		String str = Double.toString(highestRent);
		return str;
	}
	
	
	/**
	 * This method accesses each "Property" object within the array "properties" and 
	 * sums up the property rent and returns the total amount.
	 * @return totalRent
	 */
	public double totalRent() {
		double totalRent = 0.0;

		for(int j = 0; j < numberOfprop; j++)
		{
			totalRent += properties[j].getRentAmount();
		}
		return totalRent;
 }
	
	
	/**
	 * Displays the information of all the properties in the "properties" array.
	 * @return information of ALL the properties within this management company by accessing the "Properties" array.
	 * The format is as following example:  
	 */
	public String toString() {
		String display= "";
		display = "List of the properties for" + this.name + "taxID: " + this.taxId + "\n"
				       + "______________________________________________________\n";
				       
		
		                  for (int k = 0; k < numberOfprop; k++)
		                     {
			                     display += displayPropertyAtIndex(k) + "\n";   
		                     }
		
		                display+=  "__________________________________________________"
		                + "\n\ntotal management Fee: " + ((this.managmntFee * this.totalRent()) / 100);
		                
		return display;			
	}

	/**
	 * Return the name of the company
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Set the name of the company
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * return the plot of the company
	 * @return the plot
	 */
	public Plot getPlot() {
		return plot;
	}

	/**
	 * Set the name of the company
	 * @param plot
	 */
	public void setPlot(Plot plot) {
		this.plot = plot;
	}
	
	
}

